import Tables from './tables.vue'
export default Tables
