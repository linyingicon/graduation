<template>
  <h1>工作量修正</h1>
</template>

<script>
</script>

<style>
</style>
