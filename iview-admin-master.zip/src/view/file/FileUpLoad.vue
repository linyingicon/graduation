<template>

    <h1>
        小文件(1-30MB)
        <p>文件上传</p>
        <p>文件类别</p>
        <p>文件显示与下载</p>
        <p>文件检索</p>
        <i>使用全文检索引擎Lucene、solr以及elasticsearch
        https://blog.csdn.net/weixin_37886463/article/details/79447063</i>
        
    </h1>
</template>

<script>
</script>

<style>
</style>
